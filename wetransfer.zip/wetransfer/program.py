from time import sleep
import RPi.GPIO as GPIO
import motor
#motor1
DIR = 16   # Direction GPIO Pin
STEP = 20  # Step GPIO Pin
MOS = 23
#motor2
DIR2 = 5
STEP2 = 6
MOS2 = 24
#settings
CW = 1     # Clockwise Rotation
CCW = 0    # Counterclockwise Rotation
SPR = 200   # Steps per Revolution (360 / 7.5)


motor.setup()
motor.run(STEP2, DIR2, CCW, MOS2, 2)

