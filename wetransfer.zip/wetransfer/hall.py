import time
import RPi.GPIO as gpio
gpio.setmode(gpio.BCM)
hallpin0=17
hallpin1=27
hallpin2=22

def halltest(hallpin):
    gpio.setup(hallpin,gpio.IN)
    while True:
        if(gpio.input(hallpin) == False):
            print("magnet prepoznan!")
        else:
            print("ni magneta")
        time.sleep(0.5)
            
            
halltest(hallpin1)